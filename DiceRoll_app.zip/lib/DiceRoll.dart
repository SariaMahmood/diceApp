import 'dart:math';
import 'package:flutter/material.dart';

var Randomizer = Random();

class DiceRoll extends StatefulWidget {
  const DiceRoll({super.key});

  @override
  State<DiceRoll> createState() => _DiceRollState();
}

class _DiceRollState extends State<DiceRoll> {
  var currentstate = 2;
  void rolldice() {
    setState(() {
      currentstate = Randomizer.nextInt(6) + 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Center(
        child: Image.asset(
          'assets/images/$currentstate.png',
          height: 200,
          width: 200,
        ),
      ),
      TextButton(
          onPressed: rolldice,
          child: const Text(
            'Roll Dice',
            style: TextStyle(color: Colors.white, fontSize: 24),
          )),
    ]);
  }
}
