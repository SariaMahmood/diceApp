import 'dart:html';

import 'package:flutter/material.dart';

import 'dart:ui';

import 'package:diceroll_app/DiceRoll.dart';

class GradientContainer extends StatelessWidget {
  const GradientContainer(this.first_color, this.second_color, {super.key});
  final first_color;
  final second_color;

  void rolldice() {
    //..
  }
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
          colors: [first_color, second_color],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        )),
        child: Center(
          child: DiceRoll(),
        ));
  }
}
